import fetch from 'node-fetch';
import mongoose from 'mongoose';
// const fetch = require("node-fetch");
// const mongoose = require("mongoose");



mongoose.connect("mongodb+srv://user1:OaUVlhYkwrQlNXNU@cluster0.nelmozs.mongodb.net/datashow?retryWrites=true&w=majority");
//mongoose.connect("mongodb://127.0.0.1:27017/Terawork");

const PostItem = new mongoose.Schema({

    id:{
        type:Number,
        required:true
    },
    albumId:{
        type:Number,
        required:true
    },

    title:{
        type:String,
        required:true
    },

    url:{
        type:String,
        required:true
    },

    thumbnailUrl:{
        type:String,
        required:true
    }




});

const postM = mongoose.model('Post',PostItem);



async function getItmes(x) {

    const myItems = await fetch("https://jsonplaceholder.typicode.com/photos");
    const res = await myItems.json();

   // console.log(res[x]['title'])
   const postNow = new postM ({
        id:res[x]['id'],
        albumId:res[x]['albumId'],
        title:res[x]['title'],
        url:res[x]['url'],
        thumbnailUrl:res[x]['thumbnailUrl']

   });
   postNow.save();
    

        // for(let i=0; i < res.length; i++){

        //     console.log(res[i]['id'])
        // }
    //return res;
    console.log("Saved Record "+ x);
  
    
}

    //setInterval(getItmes(), 3600);

    //testdb();

    let x = 0;
    // setInterval(()=>{
        
    //     getItmes(x)
    //     x ++;
    // }, 3600);

    setInterval(()=>{
        
        getItmes(x)
        x ++;
    }, 60000);

